// pages/tips/tips.js
Page({
  getstation:function()
  {
    wx.navigateTo({
      url: '../geocoding/geocoding'
    })
  },
  music: function () {
    wx.navigateTo({
      url: '../play/play'
    })
  },
  remind:function(){
    wx.navigateTo({
      url: '../setting/setting'
   })
  },
  urgent:function(){
    wx.navigateTo({
      url: '../urgency/urgency'
    })
  }
})