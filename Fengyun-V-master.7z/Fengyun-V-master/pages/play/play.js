Page({

  /**
   * 页面的初始数据
   */
  data: {

    music_list: [
      {
        name: "大中国",
        length: 238
      },
      {
        name: "沙家浜",
        length: 323
      },
      {
        name: "最浪漫的事",
        length: 266
      },
      {
        name: "对你爱不完",
        length:198
      },
      {
        name: "月亮代表我的心",
        length: 187
      },
      {
        name: "至少还有你",
        length: 266
      },
      {
        name: "家和万事兴",
        length: 213
      },
      {
        name: "映山红",
        length: 213
      },
      {
        name: "祖国不会忘记",
        length: 223
      }],
    play: "http://m.qpic.cn/psb?/V12Iu5TV4VzazT/f1v4T6u1*rXlSXcdtxTpmstJgvIqdJnSuknfPIskcW4!/b/dFYBAAAAAAAA&bo=yADIAAAAAAADFzI!&rf=viewer_4",
    next: "http://m.qpic.cn/psb?/V12Iu5TV4VzazT/OGOU52CNW3deRGVpqipohGXtIM1kB1hPcmSCJZwY1L0!/b/dIMAAAAAAAAA&bo=yADIAAAAAAADFzI!&rf=viewer_4",
    previous: "http://m.qpic.cn/psb?/V12Iu5TV4VzazT/z4VU4GYC87SR6n5J4BkJSwNj9CakWHObXu45FXc7kjc!/b/dLgAAAAAAAAA&bo=yADIAAAAAAADFzI!&rf=viewer_4",
    playId: 0,
    //0:pause,1:play
    playButtonStatus: 0,
    playPrecent: 0,
    canPlay: false,
    vol: 20
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // wx.showToast({
    //   title: 'onShow',
    //   duration:500
    // })
    this.autoPlus()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //Function of the function is to auto move slide  ,every second ++
  autoPlus: function () {
    if (this.data.playButtonStatus == 1 && this.data.canPlay) {
      if (this.data.playPrecent < this.data.music_list[this.data.playId].length) {
        var interval = 100 / this.data.music_list[this.data.playId].length;
        this.setData({
          playPrecent: this.data.playPrecent + interval
        })
      }
      else {
        this.setData({
          playPrecent: 0
        })
        this.NextMusic()
      }
    }
    setTimeout(this.autoPlus, 1000)
  },
  sendRequest: function (obj) {
    wx.request(obj);
  },
  makeObj: function (i, sta, pre, msg) {
    var obj = {
      url: "http://api.heclouds.com/devices/576408525/datapoints?type=3",
      header: {
        "api-key": "9OM8o=CfJXkpc0KSwCLlCOsSx90=",
        "Content-Type": "application/json"
      },
      method: "post",
      data: {
        //msuci id,playing status,playing precent
        "id": i,
        "status": sta,
        "vol": this.data.vol
        //"precent":pre
      },
      success: function (res) {
        if (msg != "") {
          wx.showToast({
            title: msg,
            duration: 1000
          })
          //console.log(i);
        }
      }
    }
    return obj;
  },
  chooseMusic: function (event) {
    var temp = 0;
    //Get Choosed Music id
    var musicName = event.currentTarget.dataset.id
    for (var i = 0; i < this.data.music_list.length; i++) {
      if (musicName == this.data.music_list[i].name) {
        temp = i;
        this.sendRequest(this.makeObj(i, 1, 0, "成功播放"))
      }
    }
    this.setData({
      playPrecent: 0,
      playId: temp,
      canPlay: true,
      playingMusic: this.data.music_list[this.data.playId],
      play: "http://m.qpic.cn/psb?/V12Iu5TV4VzazT/73P8SZ4oMxpV*AF9h68IRvCntqtUVoQ1uvj2Jtv85Gc!/b/dL8AAAAAAAAA&bo=yADIAAAAAAADFzI!&rf=viewer_4",
      playButtonStatus: 1
    })
    var sta = this.data.playButtonStatus
    this.sendRequest(this.makeObj(this.data.playId, sta, 0, ""))
    // this.ProgressPlus()
  },
  PreviousMusic: function () {
    var currentId = this.data.playId;
    var finalId = 0;
    if (currentId >= 1) {
      finalId = currentId - 1
    }
    else {
      finalId = this.data.music_list.length - 1
    }
    var musicName = this.data.music_list[this.data.playId].name
    this.sendRequest(this.makeObj(this.data.playId, 1, 0, musicName + "播放成功"))
    this.setData({
      playId: finalId,
      playPrecent: 0,
      playingMusic: this.data.music_list[this.data.playId]
    })
  },
  NextMusic: function () {
    var currentId = this.data.playId;
    var finalId = 0;
    if (currentId < this.data.music_list.length - 1) {
      finalId = currentId + 1;
    }
    else {
      finalId = 0;
    }
    var musicName = this.data.music_list[this.data.playId].name
    this.sendRequest(this.makeObj(this.data.playId, 1, 0, musicName + "播放成功"))
    this.setData({
      playId: finalId,
      playPrecent: 0,
      playingMusic: this.data.music_list[this.data.playId]
    })
    //this.ProgressPlus()
    //console.log(this.data.playId);
  },
  PlayOrPause: function () {
    var pre = this.data.playPrecent
    if (this.data.playButtonStatus == 0) {
      this.data.playButtonStatus = 1;
      if (!this.data.canPlay) {
        this.setData({
          canPlay: true
        })
      }
      this.setData({
        play: "http://m.qpic.cn/psb?/V12Iu5TV4VzazT/73P8SZ4oMxpV*AF9h68IRvCntqtUVoQ1uvj2Jtv85Gc!/b/dL8AAAAAAAAA&bo=yADIAAAAAAADFzI!&rf=viewer_4"
      })
    }
    else {
      this.data.playButtonStatus = 0;
      this.setData({
        play: "http://m.qpic.cn/psb?/V12Iu5TV4VzazT/f1v4T6u1*rXlSXcdtxTpmstJgvIqdJnSuknfPIskcW4!/b/dFYBAAAAAAAA&bo=yADIAAAAAAADFzI!&rf=viewer_4"
      })

    }
    var sta = this.data.playButtonStatus
    //this.ProgressPlus()
    this.sendRequest(this.makeObj(this.data.playId, sta, pre, ""))

  },
  dragedProgress: function (e) {
    /*
    this.data.playPrecent = e.detail.value
    var sta=this.data.playButtonStatus
    var pre=this.data.playPrecent
    //this.ProgressPlus()
    this.sendRequest(this.makeObj(this.data.playId, sta, pre, ""))
    
    */
  },
  vol_change: function (e) {
    this.setData({
      vol: e.detail.value
    });
    var sta = this.data.playButtonStatus;
    var pre = this.data.precent;
    this.sendRequest(this.makeObj(this.data.playId, sta, pre, ""));

  }
})
