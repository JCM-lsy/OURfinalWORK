//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    welcome: "今日小贴士",
    "username": "爷爷奶奶好!",
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../text/text'
    })
  },
  onLoad: function () {
    console.log('onLoad')
  }
})
